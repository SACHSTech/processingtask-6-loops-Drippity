import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    size(400, 400);
  }

  public void draw() {
    background(0);

    for (int x = 0; x < width; x++){
      stroke(x, x, x);
      line(x, 200, x, 400);
    }

    fill(0);
    stroke(0);
    rect(200, 200, 200, 210);

    stroke(255);
    fill(145, 0, 255);
    for (int circleY = 40; circleY <= 360; circleY += 40) {
      for (int circleX = 40; circleX <= 360; circleX += 40) {
      ellipse(circleX+180, circleY-180, 20, 20);
      }
    }

    stroke(255);
    for (int lineX = 20; lineX <= 180; lineX += 20) {
        line(lineX, 0, lineX, 200);
    }
    for (int y = 20; y <= 200; y += 20) {
        line(0, y, 200, y);
    }

    stroke(0);
    translate(300, 300);
    fill(255);
    for(int petal = 0; petal < 8; petal++) {
      rotate(150);
      ellipse(0, 45, 20, 70);
    }

    stroke(255, 165, 0);
    fill(255, 165, 0);
    translate(0, 0);
    ellipse(0, 0, 40, 40);

  }

}